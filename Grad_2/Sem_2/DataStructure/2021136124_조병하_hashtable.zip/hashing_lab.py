# @copyright 헌귝기술교육대학교 컴퓨터공학부 자료구조및실습
# @version 2022년도 2학기
# @author: 김상진
# hashing_lab.py
# chaining 기법, 동적 배열
from typing import List, Union
from collections.abc import Iterator
import collections
from unsortedlinkedlist import SingleLinkedList

class HashTable:
	def __init__(self, capacity = 7):
		self.capacity = capacity
		self.numItems = 0
		self.table = [None]*self.capacity
		for i in range(capacity):
			self.table[i] = SingleLinkedList()
	
	def __len__(self):
		return self.numItems
	
	def _getKeyList(self):
		keyList = []
		for bucketList in self.table:
			for key in bucketList:
				keyList.append(key)
		return keyList

	def _increaseCapacity(self):
		keyList = self._getKeyList()
		self.capacity = self.capacity*2+1
		self.table = [None]*self.capacity
		for i in range(self.capacity):
			self.table[i] = SingleLinkedList()
		for key in keyList:
			index = self.hash(key)
			self.table[index].pushfront(key)

	def add(self, key: str):
		hash_value = self.hash(key)
		if self.contains(key) == False:
			if self.table[hash_value].__len__() >= 3:
				self._increaseCapacity()
				self.table[self.hash(key)].pushback(key)
			else: 
				self.table[hash_value].pushback(key)
			self.numItems += 1

	def contains(self, key: str):
		return_Value = False
		if self.table[self.hash(key)].__contains__(key) == True: return_Value = True
		return return_Value
	
	def remove(self, key: str):
		if self.table[self.hash(key)].__contains__(key) == True:
			self.table[self.hash(key)].removeFirst(key)
			self.numItems -= 1
	
	def debugPrint(self):
		print('\nhash table: ')
		for i, keyList in enumerate(self.table):
			if len(keyList)>0: 
				output = [key for key in keyList]
				print(i,':', ", ".join(output))
			else: print(i,':')
	
	def hash(self, key) -> int:
		return key.__hash__() % self.capacity
	
	def __iter__(self):
		self.visited = 0
		self.cursor = 0
		self.it = None
		self._moveForward()
		return self

	def _moveForward(self):
		while self.cursor<self.capacity:
			if len(self.table[self.cursor])>0:
				self.cursor += 1
				self.it = self.table[self.cursor-1].__iter__()
				break
			self.cursor += 1

	def __next__(self):
		if self.visited>=self.numItems: raise StopIteration
		try:
			ret = self.it.__next__()
			self.visited += 1
			return ret
		except Exception as e:
			self._moveForward()
		return self.__next__()

class FrequencyString(str):
    @property
    def normalized(self):
        try:
            return self._normalized
        except AttributeError:
            self._normalized = normalized = ''.join(sorted(collections.Counter(self).elements()))
            return normalized

    def __eq__(self, other):
        return self.normalized == other.normalized

    def __hash__(self):
        return hash(self.normalized)