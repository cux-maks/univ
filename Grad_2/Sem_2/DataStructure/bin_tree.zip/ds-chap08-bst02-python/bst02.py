# @copyright 한국기술교육대학교 컴퓨터공학부 자료구조및실습
# @version 2022년도 2학기
# @author 김상진 
# 이진 탐색 트리
# 부모 포인터를 유지하지 않음
# 최적화 및 모듈화 (findNode 중심)
# 가능한 모든 메소드를 재귀적으로 구현
from typing import List, Tuple, Callable
from collections import deque
from collections.abc import Iterator
from copy import deepcopy
from enum import Enum

class Node:
	def __init__(self, key: int) -> None:
		self.parent = None
		self.key = key
		self.left = None
		self.right = None

class TreeTraversal(Enum):
	INORDER=0
	PREORDER=1
	POSTORDER=2

class BST:
	def __init__(self, *initList: int) -> None:
		values: List[int] = initList[0] \
			if len(initList) == 1 and isinstance(initList[0], list) \
			else list(initList)
		self.clear()
		if values: 
			for key in values: self.add(key) 

	def __len__(self) -> int:
		#return self.size
		return self._numberOfNodes(self.root)
	
	def _numberOfNodes(self, node: Node) -> int:
		if node is None: return 0
		return self._numberOfNodes(node.left)+self._numberOfNodes(node.right)+1
	
	def height(self) -> int:
		return self._computeHeight(self.root)
	
	def _computeHeight(self, node: Node) -> int:
		if node is None: return -1
		return max(self._computeHeight(node.left), self._computeHeight(node.right))+1
	
	def clear(self) -> None:
		self.root = None
		self.numNodes = 0
		self.traversalMethod = TreeTraversal.INORDER

	def add(self, key: int) -> None:
		newNode = Node(key)
		if not self: 
			self.root = newNode
		else:
			newNode.parent = self._findNode(self.root, key)
			if newNode.parent.key == key: return
			if newNode.parent.key > key:
				newNode.parent.left = newNode
			else:
				newNode.parent.right = newNode

		self.numNodes += 1 

	def __contains__(self, key: int) -> bool:
		if not self: return False
		return self._findNode(self.root, key).key==key

	def _findNode(self, node: Node, key: int, parents: deque=None) -> Node:
		if node.key==key: return node
		nextNode = node.left if node.key>key else node.right
		if nextNode:
			if parents is not None: parents.appendleft(node)
			return self._findNode(nextNode, key, parents)
		return node

	def remove(self, key: int) -> None:
		if not self: return
		parents = deque()
		delNode = self._findNode(self.root, key, parents)
		if delNode.key!=key: return

		parent = parents.popleft() if parents else None
		if delNode.left and delNode.right:
			parent, prevNode = self._getLeftPredecessor(delNode)
			delNode.key = prevNode.key
			delNode = prevNode
		self._removeChild(parent, delNode)
		self.numNodes -= 1
		'''
		if not self: return
		delnode = self.root
		while True:
			if key > delnode.key:
				print("test: ", delnode.key)
				parent_node = delnode
				delnode = delnode.right
			elif key < delnode.key:
				print("test: ", delnode.key)
				parent_node = delnode
				delnode = delnode.left
			elif key == delnode.key:
				print("test: ", delnode.key)
				break
		'''

	def _removeChild(self, parent, child) -> None:
		grandChild = child.left if child.left else child.right
		if parent is None: self.root = grandChild
		else:	
			if parent.key>child.key: parent.left = grandChild
			else: parent.right = grandChild

	def _getLeftPredecessor(self, node: Node) -> tuple([Node, Node]):
		parent = node
		prev = node.left
		while prev.right:
			parent = prev
			prev = prev.right
		return parent, prev
	
	def _getRightSuccessor(self, node: Node):
		node = node.right
		while node.left: node = node.left
		return node

	def _searchParents(self, parents: deque, key: int, cmp: Callable[[int,int], bool]):
		for parent in parents:
			if cmp(parent.key,key): return parent
		return None

	def getPrev(self, key: int) -> int:
		if not self: raise RuntimeError('BST is empty')
		parents = deque()
		foundNode = self._findNode(self.root, key, parents)
		if foundNode.key != key: raise ValueError(f'{key} does not exists')
		prevNode = self._getPrevNode(foundNode, key, parents)
		return prevNode.key if prevNode else key

	def _getPrevNode(self, node: Node, key: int, parents: deque) -> Node:
		if node and node.left:
			return self._getLeftPredecessor(node)[1]
		else:
			prevNode = self._searchParents(parents, key, lambda x,y: x<y)
			return prevNode if prevNode else None

	def getNext(self, key: int) -> int:
		if not self: raise RuntimeError('BST is empty')
		parents = deque()
		foundNode = self._findNode(self.root, key, parents)
		if foundNode.key != key: raise ValueError(f'{key} does not exists')
		nextNode = self._getNextNode(foundNode, key, parents)
		return nextNode.key if nextNode else key

	def _getNextNode(self, node: Node, key: int, parents: deque) -> Node:
		if node and node.right:
			return self._getRightSuccessor(node)
		else:
			nextNode = self._searchParents(parents, key, lambda x,y: x>y)
			return nextNode if nextNode else None

	def rangeSearch(self, lo: int, hi: int) -> list:
		if lo>hi: raise ValueError('Illegal argument')
		if not self: return []
		keys = []
		self._rangeSearch(self.root, lo, hi, keys)
		return keys

	def _rangeSearch(self, node: Node, lo: int, hi: int, visitedOrder: List[int]) -> None:
		if node.left and node.key>=lo:
			self._rangeSearch(node.left, lo, hi, visitedOrder)
		if node.key>=lo and node.key<=hi: visitedOrder.append(node.key)
		if node.right and node.key<=hi:
			self._rangeSearch(node.right, lo, hi, visitedOrder)

	def nearestNeighbors(self, key: int) -> tuple([int, int]):
		parents = deque()
		foundNode = self._findNode(self.root, key, parents)
		if foundNode.key != key:
			parents.appendleft(foundNode)
		prevNode = self._getPrevNode(foundNode, key, parents)
		nextNode = self._getNextNode(foundNode, key, parents)
		prevKey = prevNode.key if prevNode else None
		nextKey = nextNode.key if nextNode else None
		return prevKey, nextKey

	def balanceTree(self):
		keys: List[int] = []
		self.inorder(self.root, keys)
		self.clear()
		self._constructBalanceTree(keys,0,len(keys)-1)

	def _constructBalanceTree(self, keys: list, lo: int, hi: int) -> None:
		if lo==hi: self.add(keys[lo])
		elif lo+1==hi:
			self.add(keys[lo])
			self.add(keys[hi])
		else:
			mid = (lo+hi)//2
			self.add(keys[mid])
			self._constructBalanceTree(keys, lo, mid-1)
			self._constructBalanceTree(keys, mid+1, hi)

	def inorder(self, node: Node, visitedOrder: List[int]) -> None:
		if node.left: self.inorder(node.left, visitedOrder)
		visitedOrder.append(node.key)
		if node.right: self.inorder(node.right, visitedOrder)

	def preorder(self, node: Node, visitedOrder: List[int]) -> None:
		visitedOrder.append(node.key)
		if node.left: self.preorder(node.left, visitedOrder)
		if node.right: self.preorder(node.right, visitedOrder)
	
	def postorder(self, node: Node, visitedOrder: List[int]) -> None:
		if node.left: self.postorder(node.left, visitedOrder)
		if node.right: self.postorder(node.right, visitedOrder)
		visitedOrder.append(node.key)			

	def setIteratorType(self, traversalMethod: TreeTraversal) -> None:
		self.traversalMethod = traversalMethod

	def __iter__(self) -> Iterator:
		self.it: int = 0
		self.keys: List[int] = []
		if self.traversalMethod==TreeTraversal.INORDER:
			self.inorder(self.root, self.keys)
		elif self.traversalMethod==TreeTraversal.PREORDER:
			self.preorder(self.root, self.keys)
		else:
			self.postorder(self.root, self.keys)
		return self

	def __next__(self) -> int:
		if self.it>=self.numNodes: raise StopIteration
		self.it += 1
		return self.keys[self.it-1]
